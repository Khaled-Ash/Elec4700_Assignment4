%
% Elec4700 Assignment 4
% Khaled AbouShaban 
% Builds on Assignment 3 with alterations and PA9
%
clear all
close all
set(0,'DefaultFigureWindowStyle','docked')

%%
% Part 1
% Given Parameters
R1 = 1;
R2 = 2;
C = 0.25;
L = 0.2;
R3 = 10;
alpaha = 100;
R4 = 0.1;
R0 = 1000;

G = zeros(7,7);
Cm = zeros(7,7);
G(1,1) = 1;
G(2,1) = -1/R1;
G(2,2) = 1/R1 + 1/R2;
G(2,6) = 1;
G(3,3) = 1/R3;
G(3,6) = -1;
G(4,3) = 1/R3;
G(4,7) = -1;
G(5,4) = -1/R4;
G(5,5) = 1/R4 + 1/R0;
G(6,2) = 1;
G(6,3) = -1;
G(7,4) = 1;
G(7,7) = -alpaha;
Cm(2,1) = -C;
Cm(2,2) = C;
Cm(6,6) = -L;

G
Cm

%%
% DC simulations
% Ignoring the C matrix GV = F
% Sweep from (-10-10) V Plot V0 & V3

F = zeros(7,1);
V = zeros(7,1);
count = 1;
for i = -10:10
    F(1) = i;
    V = G\F;
    Vo_dc(count) = V(5);
    V_3(count) = V(3);
    count = count + 1;
end

figure(1)
plot(linspace(-10,10,21),Vo_dc)
hold on;
plot(linspace(-10,10,21),V_3)
title('DC Output Voltage Vs Input Voltage')
xlabel('Input')
ylabel('Output')
legend('Vo','V3')
grid on;

%%
% AC simulations
% 

j = sqrt(-1);

count = 1;
F(1) = 1;
for w = 0:1000
    Gac = G + j*w*Cm;
    V = Gac\F;
    Voac(count) =  V(5); %Setting Vo for AC
    count = count+1;
end

figure(2)
plot(0:1000,abs(Voac))
grid on;
title('Ouput Voltage vs Frequency')
xlabel('Frequency (rad/s)')
ylabel('Vo')


figure(3)
semilogx(0:1000, log10(abs(Voac)))
grid on;
hold on;
title('Gain vs Frequency')
xlabel('Frequncy (rad/s)')
ylabel('Gain (dB)')


%%
% Gain histo as function of C pertubations

Crand = Cm;
for i = 1:1000
    Cr = normrnd(C,0.05);
    Crand(2,1) = -Cr;
    Crand(2,2) = Cr;
    V = (j*pi*Crand + G)\F;
    Vorand(i) = V(5);
end
figure(4)
hist(abs(Vorand));
grid on;
title('Gain Histogram for Random C Pertubations')
xlabel('Gain')
ylabel('Number of Occurences')

%%
% Transient simulation of this circuit
%  VdV/dt + GV = F => (C/dt + G)V(j) = CV(j-1)/dt + F(t(j))

dt = 0.001;

A_trans = Cm/dt + G;

V_1 = zeros(7,1);
V_2 = zeros(7,1);
V_3 = zeros(7,1);
V_o1(1) = 0;
V_o2(1) = 0;
V_o3(1) = 0;
V_i1(1) = 0;
V_i2(1) = 0;
V_i3(1) = 0;
F_1 = zeros(7,1);
F_2 = zeros(7,1);
F_3 = zeros(7,1);
count = 1;
for t = dt:dt:1
    if t >= 0.03
        F_1(1) = 3;
    end
    F_2(1) = sin(2*pi*t/0.03);
    F_3(1) = exp(-0.5*((t - 0.06)/0.03)^2);
    V_1 = A_trans\(Cm*V_1/dt + F_1);
    V_2 = A_trans\(Cm*V_2/dt + F_2);
    V_3 = A_trans\(Cm*V_3/dt + F_3);
    V_i1(count +1) = V_1(1);
    V_i2(count +1) = V_2(1);
    V_i3(count +1) = V_3(1);
    V_o1(count +1) = V_1(5);
    V_o2(count +1) = V_2(5);
    V_o3(count +1) = V_3(5);
    count = count+1;
end

figure(5)
plot(0:dt:1,V_i1)
hold on;
grid on;
plot(0:dt:1,V_o1)
title('Voltage vs Time')
xlabel('Time (s)')
ylabel('Voltage')
legend('Input','Output')

figure(6)
plot(0:dt:1,V_i2)
hold on;
grid on;
plot(0:dt:1,V_o2)
title('Voltage vs Time')
xlabel('Time (s)')
ylabel('Voltage')
legend('Input','Output')

figure(7)
plot(0:dt:1,V_i3)
hold on;
grid on;
plot(0:dt:1,V_o3)
title('Voltage vs Time')
xlabel('Time (s)')
ylabel('Voltage')
legend('Input','Output')

%%
% Fourier Transform

X_in = fft(V_i1); % Fourier transform
P2_in = abs(X_in/1000);
P1_in = P2_in(1:1000/2+1);
P1_in(2:end-1) = 2*P1_in(2:end-1); 
f = (1/dt)*(0:(1000/2))/1000; % Sampling freq

figure(8)
plot(f,P1_in)
grid on;

Xo = fft(V_o1);
P2o_ = abs(Xo/1000);
P1_o = P2o_(1:1000/2+1);
P1_o(2:end-1) = 2*P1_o(2:end-1);
f = (1/dt)*(0:(1000/2))/1000;
hold on;
grid on;
plot(f,P1_o)
title('Frequency Step Input')
xlabel('Frequency (Hz)')
ylabel('Amplitude')
ylim([0 3])
legend('Input','Output')

%%
% For the step input we see that the fourier transform of the step is the
% sinc function. We see at the output we have a slightly distorted sinc
% function. This distorion comes from the fact that the gain in the pass
% band is not constant. Furthermore we see that the higher frequency
% components are attenuated.

X_in = fft(V_i2); %Take fourier transform
P2_in = abs(X_in/1000);
P1_in = P2_in(1:1000/2+1);
P1_in(2:end-1) = 2*P1_in(2:end-1); % Calculate singel ended spectrum
figure(9)
grid on;
plot(f,P1_in)

Xo = fft(V_o2);
P2o_ = abs(Xo/1000);
P1_o = P2o_(1:1000/2+1);
P1_o(2:end-1) = 2*P1_o(2:end-1);
hold on;
grid on;
plot(f,P1_o)
title('Frequency for Sinusoidal Input')
xlabel('Frequency (Hz)')
ylabel('Amplitude')
ylim([0 3])
legend('Input','Output')

%%
% For the sinusiodal input we see that the frequency response has two peaks
% at about 33Hz witch is the frequency of the input and output signal.

X_in = fft(V_i3); %Taking fourier transform
P2_in = abs(X_in/1000);
P1_in = P2_in(1:1000/2+1);
P1_in(2:end-1) = 2*P1_in(2:end-1);
figure(10)
plot(f,P1_in)
grid on;

Xo = fft(V_o3);
P2o_ = abs(Xo/1000);
P1_o = P2o_(1:1000/2+1);
P1_o(2:end-1) = 2*P1_o(2:end-1);
hold on
plot(f,P1_o)
title('Frequency for Gaussian Input')
xlabel('Frequency (Hz)')
ylabel('Amplitude')
ylim([0 3])
legend('Input','Output')

%%
% For the gaussian input we see that the fourier transform of a gaussian
% signal is also a gaussian signal. Since the majority of the frequency
% response of the gaussian input falls within the pass band of this
% circuit, we see a gaussian frequency response at the output as well.

%% Part 3
% Circuit W/Noise
% imporved model by adding a noise current source and Capacitor

In = 0.001; % Current Source in parallel with R3
Cn = 0.00001; %Capacitor in Parallel with R
Cm(3,3) = Cn;

G  %Updated G Matrix
Cm %Updated Cm Matrix
dt = 0.001;
A_trans = Cm/dt + G;

F = zeros(7,1);
V = zeros(7,1);
Vo(1) = 0;
Vi(1) = 0;

count = 1;

for t = dt:dt:1
    F(1) = exp(-0.5*((t - 0.06)/0.03)^2);
    F(3) = In*normrnd(0,1);
     V = A_trans\(Cm*V/dt + F);
     Vi(count + 1) = F(1);
     Vo(count + 1) = V(5);
     count = count + 1;
end

figure(11)
plot(0:dt:1,Vi)
hold on;
grid on;
plot(0:dt:1,Vo)
title('Voltage vs Time')
xlabel('Time (s)')
ylabel('Voltage')
legend('Input','Output')

X_in = fft(Vi);
P2_in = abs(X_in/1000);
P1_in = P2_in(1:1000/2+1);
P1_in(2:end-1) = 2*P1_in(2:end-1);
f = (1/dt)*(0:(1000/2))/1000;

figure(12)
grid on;
plot(f,P1_in)

Xo = fft(Vo);
P2o_ = abs(Xo/1000);
P1_o = P2o_(1:1000/2+1);
P1_o(2:end-1) = 2*P1_o(2:end-1);
f = (1/dt)*(0:(1000/2))/1000;
hold on;
plot(f,P1_o)
title('Frequency for Noisy Resistor')
xlabel('Frequency (Hz)')
ylabel('Amplitude')
ylim([0 3])
legend('Input','Output')

%%
% 2 Varying Cn 
% for Cn = 0, Cn = 0.001 and Cn = 0.1

C_small = Cm;
C_reg = Cm;
C_lg = Cm;
C_small(3,3) = 0;
C_reg(3,3) = 0.001;
C_lg(3,3) = 0.1;


V_small = zeros(7,1);
V_reg = zeros(7,1);
V_lg = zeros(7,1);
Vo_small(1) = 0;
Vo_reg(1) = 0;
Vo_lg(1) = 0;
Vi(1) = 0;

count = 1;

for t = dt:dt:1
     F(1) = exp(-0.5*((t - 0.06)/0.03)^2);
     F(3) = In*normrnd(0,1);
     V_small = (C_small/dt + G)\(C_small*V_small/dt + F);
     V_reg = (C_reg/dt + G)\(C_reg*V_reg/dt + F);
     V_lg = (C_lg/dt + G)\(C_lg*V_lg/dt + F);
     Vo_small(count + 1) = V_small(5);
     Vo_reg(count + 1) = V_reg(5);
     Vo_lg(count + 1) = V_lg(5);
     Vi(count + 1) = F(1);
     count = count + 1;
end

figure(13)
plot(0:dt:1,V_i1)
hold on;
grid on;
plot(0:dt:1,Vo_small)
title('Voltage vs Time Cn = 0')
xlabel('Time (s)')
ylabel('Voltage')
legend('Input','Output')


figure(14)
plot(0:dt:1,Vi)
hold on;
grid on;
plot(0:dt:1,Vo_reg)
title('Voltage vs Time Cn = 0.001')
xlabel('Time (s)')
ylabel('Voltage')
legend('Input','Output')

figure(15)
plot(0:dt:1,Vi)
hold on;
grid on;
plot(0:dt:1,Vo_lg)
title('Voltage vs Time Cn = 0.1')
xlabel('Time (s)')
ylabel('Voltage')
legend('Input','Output')


%%
% Comment =>  initially, noise is reduced as the capacitor is increased
% The further increase caused the output signal to become distorted as 
% the higher frequency harmonics became amplified

%%
% Varying the time step
% The simulation for time steps at dt = 0.003 and dt = 0.1

dt1 = 0.01;
Vi_SmStep(1) = 0;
Vo_SmStep(1) = 0;
V = zeros(7,1);
count = 1;

for t = dt1:dt1:1
     F(1) = exp(-0.5*((t - 0.06)/0.03)^2);
     F(3) = In*normrnd(0,1);
     V = (Cm/dt1 + G)\(Cm*V/dt1 + F);
     Vo_SmStep(count + 1) = V(5);
     Vi_SmStep(count + 1) = F(1);
     count = count + 1;
end

dt2 = 0.1;
Vi_LgStep(1) = 0;
Vo_LgStep(1) = 0;
V = zeros(7,1);
count = 1;

for t = dt2:dt2:1
     F(1) = exp(-0.5*((t - 0.06)/0.03)^2);
     F(3) = In*normrnd(0,1);
     V = (Cm/dt2 + G)\(Cm*V/dt2 + F);
     Vo_LgStep(count + 1) = V(5);
     Vi_LgStep(count + 1) = F(1);
     count = count + 1;
end

figure(16)
plot(0:dt1:1,Vi_SmStep)
hold on; 
grid on;
plot(0:dt1:1,Vo_SmStep)
title('Voltage vs Time dt = 0.003')
xlabel('Time (s)')
ylabel('Voltage')
legend('Input','Output')

figure(17)
plot(0:dt2:1,Vi_LgStep)
hold on;
grid on;
plot(0:dt2:1,Vo_LgStep)
title('Voltage vs Time dt = 0.01')
xlabel('Time (s)')
ylabel('Voltage')
legend('Input','Output')

%%
% Comment => The observation is that as step is increased, the results of the
% simulation can become random and inaccurate
% This is due to accuracy of the finite difference approximation
% being inversly proportional to the step size

%%
%
% Non-Linearity
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



